#include<bits/stdc++.h>
#include<string.h>
using namespace std;
const int N = 2010;
const int M = 1e4+10;
typedef long long ll;
const int INF = 0x3f3f3f3f;
const ll INF64 = 1e18;
typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;
#define mysort(a) sort(a.begin(),a.end());
#define myreverse(a) reverse(a.begin(),a.end());
#define all(a) a.begin(),a.end()
#define NOT_EXIST string::npos
const int MOD = 998244353;
typedef __int128 sll;
//#define int long long



void solve() {
    int n,m;
    cin>>n>>m;
    vector<int> a(n);
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    int t = m-2;
    for(int i=0;i<n;i++) {
        if (a[i] == t) {
            cout<<1<<'\n';
            cout << a[i] << endl;
            return;
        }
    }
    mysort(a);
    for(int i=0;i<n-1;i++){
        int l=i+1,r=n-1;
        while(l<=r){
            int mid = l+r>>1;
            if(a[mid]+a[i]==t){
                cout<<2<<'\n';
                cout<<a[i]<<" "<<a[mid]<<endl;
                return;
            }
            else if(a[mid]+a[i]<t){
                l=mid+1;
            }
            else{
                r=mid-1;
            }
        }
    }
    cout<<-1<<endl;
}



signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    //system("chcp 65001");
    int testcase=1;
    //cin >> testcase;
    while(testcase--){
        solve();
    }
    return 0;
}
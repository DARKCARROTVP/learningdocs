#include <windows.h>
#include <stdio.h>
#include <process.h>

HANDLE mutex;

unsigned __stdcall FirstThreadFunc(void *pArguments)
{
	int i;
	WaitForSingleObject(mutex, INFINITE);
	for(i=0; i<10; i++){
		printf("�����߳�1��i=%d\n",i);
		Sleep(100);
	}
	ReleaseMutex(mutex);
    return 0;
}

unsigned __stdcall SecondThreadFunc(void *pArguments)
{
	int i;
	WaitForSingleObject(mutex, INFINITE);
	for(i=0; i<10; i++){
		printf("�����߳�2��i=%d\n",i);
		Sleep(100);
	}
	ReleaseMutex(mutex);
    return 0;
}


int main()
{
	HANDLE hThread[2];
	unsigned threadID[2];

	mutex = CreateMutex(NULL, FALSE, NULL);

    hThread[0] = (HANDLE)_beginthreadex(NULL, 0, FirstThreadFunc, NULL, 0, &threadID[0]);
    hThread[1] = (HANDLE)_beginthreadex(NULL, 0, SecondThreadFunc, NULL, 0, &threadID[1]);
	 
	WaitForSingleObject(hThread[0],INFINITE);
	WaitForSingleObject(hThread[1],INFINITE);

	// Destroy the objects.
	CloseHandle(hThread[0]);
    CloseHandle(hThread[1]);
	CloseHandle(mutex);
	printf("�����̶߳�ִ������ˡ�\n");
	getchar();
	return 0;
}
